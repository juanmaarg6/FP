/*
Fichero subvector.cpp
Implementar un programa que, dado un vector de enteros, muestre por pantalla el subvector cuya suma de sus elementos sea máxima. Por ejemplo, si el vector es {1, 2, -5, 4, 1,-3, 2}, entonces el subvector es {4,1}, que suma 5. Por subvector se entiende un conjunto de componentes consecutivas del vector original.

*/
#include <iostream>

using namespace std;

int main(){
    
    const int LONGMAXIMA = 10;
    int longitud;
    int vector[LONGMAXIMA]={0};
    
    cout << "\nIntroduce la longitud del vector\n";
    cin >> longitud;
    
    cout << "Introduce las componentes del vector\n";
    for (int i=0; i<longitud; i++)
        cin >> vector[i];
    
    int suma = 0;
    int maxima_suma = vector[0];
    int posicion_comienzo = 0;
    int longitud_subvector = 0;
    
    /*
     Algoritmo:
     Para cada posicion en el vector,
        vamos sumando progresivamente todas las componentes desde la posicion hasta el final
        si al añadir una componente se supera la maxima suma obtenida hasta el momento, se almacena la posicion de comienzo y las componentes sumadas
     */
    for (int i=0; i<longitud; i++){
        suma = 0;
        for (int j=i; j<longitud; j++){
            suma = suma + vector[j];
            if ( suma > maxima_suma ){
                maxima_suma = suma;
                posicion_comienzo = i;
                longitud_subvector = j-i+1;
            }
        }
    }
    
    cout << "El subvector es: ";
    for (int i=0; i<longitud_subvector; i++)
        cout << vector[i+posicion_comienzo] << " ";
    cout << "\nLa suma es: " << maxima_suma << "\n";
}

