/*
Fichero matriz.cpp
En una matriz de caracteres de dimension fxc puede haber, en cada casilla, el caracter 'X', o bien el caracter '.'. Disenar y escribir un programa que encuentre la mayor secuencia consecutiva, horizontal o vertical, de puntos existente en la matriz. Para ello, debe devolver la fila y la columna donde comienza la secuencia y su orientacion: 'h' para orientacion horizontal y 'v' para vertical. En caso de empate entre una secuencia horizontal y otra vertical, se devolvera preferentemente la secuencia con orientacion horizontal. En caso de empate entre dos secuencias horizontales, se devolvera la de menor valor de fila. En caso de empate entre dos secuencias verticales, se devolvera la de menor valor de columna. En caso de que la matriz no contenga ningun punto, debe devolver fila=-1, col=-1 y orientacion=h.
*/
#include <iostream>

using namespace std;

int main(){
    
    const int MAX = 10;
    char matriz[MAX][MAX];
    
    int filas, columnas;
    cout << "Introduce el numero de filas y columnas: \n";
    cin >> filas >> columnas;
    
    cout << "Introduce la matriz: \n";
    for (int i=0; i<filas; i++)
        for (int j=0;j<columnas; j++)
            cin >> matriz[i][j];
   
    int numero_solucion = 0;
    int fila_solucion = -1;
    int columna_solucion = -1;
    char orientacion_solucion = 'h';
    
    int suma = 0;
    bool seguir = true;
    
    /*
     * Algoritmo:
     * Primero para horizontal y despues para vertical:
     * Para cada posicion en la matriz:
     *      - si es un punto:
     *          - calcular el numero de puntos a partir de esa casilla hasta una X o final de la matriz
     *          - si supera el maximo, se actualiza el maximo al actual
     */
    
    for (int i=0; i<filas; i++)
        for (int j=0; j<columnas; j++)
            if ( matriz[i][j] == '.' ){
                suma = 1;
                seguir = true;
                while ( seguir && j+suma < columnas ){
                    if (matriz[i][j+suma] == '.')
                        suma++;
                    else
                        seguir = false;
                }
                if ( suma > numero_solucion ){
                    numero_solucion = suma;
                    fila_solucion = i;
                    columna_solucion = j;
                }
            }
    
    for (int i=0; i<filas; i++)
        for (int j=0; j<columnas; j++)
            if ( matriz[i][j] == '.' ){
                suma = 1;
                seguir = true;
                while ( seguir && i+suma < filas  ){
                    if (matriz[i+suma][j] == '.')
                        suma++;
                    else
                        seguir = false;
            }
            if ( suma > numero_solucion ){
                numero_solucion = suma;
                fila_solucion = i;
                columna_solucion = j;
                orientacion_solucion = 'v';
            }
        }
    
    cout << "Fila: " << fila_solucion << " Columna: " << columna_solucion << " Orientacion: " << orientacion_solucion << " Numero: " << numero_solucion << "\n";
}

