/*
Fichero circunferencia.cpp
Implementar una clase Circunferencia para representar una circunferencia en el plano. En particular, disenar la clase utilizando unos datos miembro adecuados (1 punto). Implementar un constructor por defecto que inicialice a la circunferencia unidad, y un constructor con parametros (1 punto). Implementar un metodo que decida si dos circunferencias se intersecan o no (1 punto).
Implementar una funcion main para probar la clase. La funcion main no se evaluara.

*/
#include <iostream>
#include <cmath>

using namespace std;

/*
 *@brief un objeto de la clase Punto2D representa un punto en el plano
 */
class Punto2D{
    private:
        double abcisa;/**< primera componente del punto */
        double ordenada;/**< segunda componente del punto */
    public:
        /*
         *@brief Constructor por defecto, incializa al punto (0,0)
         *
         */
        Punto2D (){
            abcisa = 0;
            ordenada = 0;
        }
        /*
         *@brief Funcion que asigna valores a los datos miembro de un Punto2D
         *@param x,y los valores a asignar
         */
        void SetPunto ( double x, double y ){
            abcisa = x;
            ordenada = y;
        }
        /*
         *@brief Funcion que calcula la distancia entre un Punto2D y *this
         */
        double Distancia( Punto2D otro ){
            double distancia_ordenadas = ordenada - otro.ordenada;
            double distancia_abcisa = abcisa - otro.abcisa;
    
            double distancia_puntos = distancia_abcisa * distancia_abcisa + distancia_ordenadas * distancia_ordenadas;
    
            return sqrt(distancia_puntos);
        }
};

/*
*@brief un objeto de la clase Circunferencia representa una circunferencia en el plano
*/
class Circunferencia{
    private:
        Punto2D centro;/**< centro de la circunferencia */
        double radio;/**< radio de la circunferencia */
    public:
        /*
         *@brief Constructor por defecto
         *@post inicializa a la circunferencia centrada en (0,0) de radio 1
        */
        Circunferencia(){
            centro.SetPunto(0,0);
            radio = 1;
        }
        /* o bien,
         Circunferencia(): radio(1){
         }
         */
        /*
         *@brief Constructor con parametros
         *@param c Centro de la circunferencia
         *@param r Radio de la circunferencia
         */
        Circunferencia( Punto2D c, double r ){
            centro = c;
            radio = r;
        }
        /*
         *@brief Metodo que decide si dos circunferencias intersecan
         *@param c Una de las circunferencias, la otra es *this
         *@return true si tienen algún punto en comun, false en otro caso.
         */
        bool Intersecar( Circunferencia c ){
            double distancia_centros = centro.Distancia( c.centro );
            
            bool fuera = distancia_centros > radio + c.radio;
            bool dentro = distancia_centros < abs(radio - c.radio);
            
            bool interseca = fuera || dentro;
            
            return !interseca;
        }
};



int main(){
    
    Punto2D a,b;
    
    int numero;
    cin >> numero;
    
    double ab, ord, r;
    for (int i=0; i<numero; i++){
        cin >> ab >> ord;
        a.SetPunto(ab,ord);
        cin >> r;
        Circunferencia una(a,r);
        cin >> ab >> ord;
        b.SetPunto(ab,ord);
        cin >> r;
        Circunferencia otra(b,r);
        cout << una.Intersecar(otra) << " " << otra.Intersecar(una) << "\n";
    }
}

