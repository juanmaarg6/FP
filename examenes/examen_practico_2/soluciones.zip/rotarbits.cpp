/*
Fichero rotarbits.cpp

Implementar una funcion
int RotarBits(int numero, int veces, bool direccion);
que devuelva el numero que se obtiene al desplazar los bits/dgitos de la representacion en binario del entero positivo numero tantas posiciones como indica veces en la direccion que indica direccion (true para la derecha, false para la izquierda), donde la traslacion es ciclica (el siguiente al ultimo es el primero).
*/

#include <iostream>

using namespace std;

/*
 *@brief Funcion que calcula el numero resultante al desplazar los bits una posicion a la derecha en la representacion en binario de un entero no negativo dado
 *@param numero el entero a considerar
 *@param bits el numero de bits bajo los que se considera numero
 *@pre numero no es negativo y bits debe ser mayor o igual que el numero de digitos en binario de numero
 */
int DesplazarDerecha(int numero, int bits){
    
    /* Algoritmo:
     * - Se calcula las unidades en binario
     * - Se divide el numero entre dos (= desplazamiento a derecha una posicion)
     * - Se colocan las unidades en la cifra mas significativa (multiplicar unidades por 2^(bits-1)
     */
    int unidades = numero % 2;
    numero = numero/2;
    
    int potencia = 1;
    for ( int i=0; i<bits-1; i++ )
        potencia = potencia * 2;
    
    numero = numero + potencia * unidades;
    
    return numero;
}

/*
*@brief Funcion que calcula el numero resultante al desplazar los bits una posicion a la izquierda
*          en la representacion en binario de un entero no negativo dado
*@param numero el entero a considerar
*@param bits el numero de bits bajo los que se considera numero
*@pre numero no es negativo y bits debe ser mayor o igual que el numero de digitos en binario de numero
*/
int DesplazarIzquierda(int numero, int bits){
    int copia_numero = numero;
    
    /* Algoritmo:
    * - Se calcula la cifra mas significatica en binario
    * - Se elimina (se resta 2^(bits-1) por esa cifra)
    * - Se multiplica por 2 y se suma la cifra mas significativa
    */
    int potencia = 1;
    for ( int i=0; i<bits-1; i++ ){
        potencia = potencia * 2;
        copia_numero = copia_numero / 2;
    }
    
    numero = numero - copia_numero * potencia;
    numero = numero * 2;
    numero = numero + copia_numero;
        
    /*  Menos eficiente (= mas lento), pero codigo mas sencillo
    for (int i=0; i<bits-1; i++)
       numero = DesplazarDerecha(numero,bits);
     */
    
    return numero;
    }

/*
*@brief Funcion que calcula el numero de digitos en la representacion en binario de un entero
*@param numero el entero a considerar
*@pre numero no es negativo
*/
int CalcularDigitosBinario(int numero){
    int contador = 0;
    
    while (numero > 0){
        contador++;
        numero = numero/2;
    }
    
    return contador;
}

/*
 *@brief Funcion que modifica un numero desplazando un numero de digitos su representacion
 *          en base dos
 *@param numero el entero al que se le desplazan los digitos
 *@param veces el numero de posiciones que se desplazan los digitos
 *@param direccion true para derecha y false para izquierda
 *@pre el entero debe ser no negativo
 *@return un entero positivo correspondiente al entero con los digitos en binario desplazados
 */
int Desplazar (int numero, int veces, bool direccion){
    int numerobits = CalcularDigitosBinario(numero);
    
    if ( direccion )
        for (int i = 0; i < veces; i++)
            numero = DesplazarDerecha(numero,numerobits);
    else
        for (int i = 0; i< veces; i++)
            numero = DesplazarIzquierda(numero, numerobits);
        
    return numero;
}


int main(){
    int num;
    int veces;
    cin >> veces;
    
    for (int i=0;i<veces; i++){
        cin >> num;
        cout << Desplazar (num,0,1) << " " << Desplazar(num,0,0) << " | ";
        for (int j=1; j<6; j++)
            cout << Desplazar (num,j,1) << " ";
        cout << " | ";
        for (int j=1; j<6; j++)
            cout << Desplazar(num,j,0) << " ";
        cout << "\n";
    }
}

