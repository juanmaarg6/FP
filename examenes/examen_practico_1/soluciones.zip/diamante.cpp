/*
Fichero diamante.cpp
Muestra la figura
    *
   *-*
  *---*
 *-----*
  *---*
   *-*
    *
 por pantalla, para una altura dada.
*/
#include <iostream>

using namespace std;

int main(){
    
    int altura;
    bool altura_correcta;
    
    do{
        cout << "\nInserta altura\n";
        cin >> altura;
        
        altura_correcta = altura > 0 && altura % 2 != 0;
    }while (!altura_correcta);
    
    int mitad = altura / 2;
    
    /* Para la primera mitad del rombo (i fila, j columna):
      - hay asterisco si j=mitad-i o j=mitad+i
      - hay guion si mitad-i < j < mitad+i
      - hay espacio en otro caso
     
     La segunda mitad del rombo es lo mismo, pero con i en
     sentido descendente
    */
    
    for (int i=0; i<=mitad; i++){
        for (int j=0; j<altura; j++)
            if (j == mitad - i || j == mitad + i)
                cout << "*";
            else if (j > mitad - i && j < mitad + i)
                cout << "-";
            else
                cout << " ";
        cout << "\n";
    }
    
    for (int i=mitad-1; i>=0; i--){
        for (int j=0; j<altura; j++)
            if (j == mitad - i || j == mitad + i)
                cout << "*";
            else if (j > mitad - i && j < mitad + i)
                cout << "-";
            else
                cout << " ";
        cout << "\n";
    }
}

