/*
Fichero secuencia.cpp
Calcula en base decimal el complemento a dos de un numero en binario de longitud arbitraria
 Version 2: Secuencia de numeros binarios
*/
#include <iostream>

using namespace std;

int main(){
    
    char entrada;
    bool acarreo = true;
    const char TERMINADOR = '#';
    const int ZERO = '0';
    int digito = 0;
    int potencia_2 = 1;
    int suma = 0;
    int numero_almohadillas = 0;
    int entrada_entero;
    int numero_ceros = 0, numero_unos = 0;
    bool correcto = true;
   
    cout << "\nInsertar secuencia binaria (# para terminar)\n";

    /* Para cada digito en binario:
     - si es necesario, se corrige.
     - cambio de 0 a 1, o al revés, sumo acarreo y calculo modulo 2
     - actualizamos acarreo
     - añado a un acumulador el digito
       resultante por la potencia de 2 correspondiente
     - Al insertar # se reinicia, con otra #, acaba
    */
    
    do{
        cin >> entrada;
        
        correcto = entrada == '0' || entrada == '1' || entrada == '#';
        
        /* Algoritmo de correccion:
         - convertir a entero el caracter
         - dividir sucesivamente entre 2 para calcular digitos en binario
         - si tiene mas unos, corrige a 1
         - si tiene mas ceros, corrige a 0
         - en otro caso, corrige a #
         */

        if ( !correcto ){
            entrada_entero = entrada;
           
            while ( entrada_entero != 0 ){
                if ( entrada_entero % 2 == 1 )
                    numero_unos++;
                entrada_entero = entrada_entero / 2;
            }
            numero_ceros = 8 - numero_unos;
            
            if  ( numero_unos > numero_ceros )
                entrada = '1';
            else if ( numero_ceros > numero_unos )
                entrada = '0';
            else
                entrada = TERMINADOR;
            
            numero_ceros = numero_unos = 0;
        }
        
        if ( entrada == TERMINADOR )
            numero_almohadillas++;
        
        while ( entrada != TERMINADOR ){
            numero_almohadillas = 0;
            
            digito = entrada - ZERO; // transformar caracter a entero
        
            if ( !acarreo )
                digito = (digito + 1) % 2;
            if ( acarreo && digito == 1 )
                acarreo = false;
            
            suma = suma + digito * potencia_2;
        
            cin >> entrada;
            
            correcto = entrada == '0' || entrada == '1' || entrada == '#';
            if ( !correcto ){
                entrada_entero = entrada;
               
                while ( entrada_entero != 0 ){
                    if ( entrada_entero % 2 == 1 )
                        numero_unos++;
                    entrada_entero = entrada_entero / 2;
                }
                numero_ceros = 8 - numero_unos;
                
                if  ( numero_unos > numero_ceros )
                    entrada = '1';
                else if ( numero_ceros > numero_unos )
                    entrada = '0';
                else
                    entrada = TERMINADOR;
                
                numero_ceros = numero_unos = 0;
            }
            
            potencia_2 = potencia_2 * 2;
        }
        
        if ( numero_almohadillas == 0 ){
            cout << suma << "\n";
            numero_almohadillas++;
            suma = 0;
            acarreo = true;
            potencia_2 = 1;
        }
    }while ( numero_almohadillas < 2 );
}


