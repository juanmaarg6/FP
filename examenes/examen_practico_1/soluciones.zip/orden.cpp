/*
Fichero orden.cpp
Programa que calcula el orden de dos naturales cualesquiera
*/
#include <iostream>

using namespace std;

int main(){
    
    int a = 0, b = 0;
    int numero1, numero2;
    int contador1 = 0, contador2 = 0;
    
    bool a_mayor_b = false;
    bool b_mayor_a = false;
    bool es_mayor = a_mayor_b || b_mayor_a;

    cout << "\nInsertar dos numeros positivos\n";
    cin >> a >> b;
    
    numero1 = a;
    numero2 = b;
    
    /*
     * Para una cifra (empezando en 9):
     * - Calcula numero de digitos con esa cifra en a y en b
     * - Si alguno es mayor, termina
     * - Si no, prueba con uno menos. Si la cifra era cero, son iguales.
    */
    for (int i=9; i>=0 && !es_mayor; i--){
        while (numero1 > 0){
            if (numero1 % 10 == i)
                contador1++;
            numero1 = numero1 / 10;
        }
        
        while (numero2 > 0){
            if (numero2 % 10 == i)
                contador2++;
            numero2 = numero2 / 10;
        }
        
        a_mayor_b = contador1 > contador2;
        b_mayor_a = contador1 < contador2;
        es_mayor = a_mayor_b || b_mayor_a;
        
        contador1 = 0;
        contador2 = 0;
        numero1 = a;
        numero2 = b;
    }
    
    if (!es_mayor)
        cout << "\nSon iguales\n";
    else if (a_mayor_b)
        cout << "\na mayor que b\n";
    else
        cout << "\nb mayor que a\n";
}

