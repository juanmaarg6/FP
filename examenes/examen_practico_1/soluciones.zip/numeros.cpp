/*
Fichero numeros.cpp
Calcula los numeros de tres cifras, y la cantidad, tales que:
    - no se repiten las cifras
    - las cifras estan entre 1 y 4
*/
#include <iostream>

using namespace std;

int main(){
    
    const int LIMITE_SUPERIOR = 5;
    int contador = 0;
    
    /* Algoritmo:
     Para cada posibilidad de los tres digitos:
        si no se repiten, mostrarlo y aumentar el contador
     */
    
    for (int i=1; i<=LIMITE_SUPERIOR; i++)
        for (int j=1; j<=LIMITE_SUPERIOR; j++)
            for (int k=1; k<=LIMITE_SUPERIOR; k++)
                if (i != j && i != k && j != k){
                    cout << i << j << k << " ";
                    contador ++;
                }
     
    cout << "\nEl numero de enteros positivos es: " << contador << "\n";    
}

